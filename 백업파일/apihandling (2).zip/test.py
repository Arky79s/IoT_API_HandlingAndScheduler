
from datetime import datetime, timedelta


#now = datetime.now().timestamp()
#print("1st:"+now)
resTime=datetime.now()+timedelta(minutes=2)
print(resTime)