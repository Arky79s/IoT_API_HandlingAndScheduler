data='temperature_28'

print(data.split('_')[0][0].upper())