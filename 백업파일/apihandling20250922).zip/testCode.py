

temp2intdata=int(34)

minpoint=int(18)
maxpoint=int(32)

if minpoint <= temp2intdata <= maxpoint : #validation
    print("성공")
    suseccedFlag = True
else:    
    suseccedFlag = False
    print("실패")
