
from datetime import datetime, timedelta

for i in range(1, 41) :
    print(i)
    break